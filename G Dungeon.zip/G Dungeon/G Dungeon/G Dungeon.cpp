#include <iostream>
using namespace std;
#include <time.h>
#include <cstdlib>
#include <ctime>


void titleScreen()
{
	cout << " _____                                                                       _____ \n";
	cout << "( ___ )                                                                     ( ___ )\n";
	cout << " |   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|   | \n";
	cout << " |   |  ,----.       ,------.                                                |   | \n";
	cout << " |   | '  .-./       |  .-.  \\ ,--.,--.,--,--,  ,---.  ,---.  ,---. ,--,--,  |   | \n";
	cout << " |   | |  | .---.    |  |  \\  :|  ||  ||      \\| .-. || .-. :| .-. ||      \\ |   | \n";
	cout << " |   | '  '--'  |    |  '--'  /'  ''  '|  ||  |' '-' '\\   --.' '-' '|  ||  | |   | \n";
	cout << " |   |  `------'     `-------'  `----' `--''--'.`-  /  `----' `---' `--''--' |   | \n";
	cout << " |   |                                         `---'                         |   | \n";
	cout << " |___|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|___| \n";
	cout << "(_____)                                                                     (_____)\n";
}
//shows the title screen

void deathScreen()
{

	cout << "\n__| |__________________________________________________| |__";
	cout << "\n__   __________________________________________________   __";
	cout << "\n  | |                                                  | |  ";
	cout << "\n  | |__     ______  _    _   _____ _____ ______ _____  | |  ";
	cout << "\n  | |\\ \\   / / __ \\| |  | | |  __ \\_   _|  ____|  __ \\ | |  ";
	cout << "\n  | | \\ \\_/ / |  | | |  | | | |  | || | | |__  | |  | || |  ";
	cout << "\n  | |  \\   /| |  | | |  | | | |  | || | |  __| | |  | || |  ";
	cout << "\n  | |   | | | |__| | |__| | | |__| || |_| |____| |__| || |  ";
	cout << "\n  | |   |_|  \\____/ \\____/  |_____/_____|______|_____/ | |  ";
	cout << "\n__| |__________________________________________________| |__";
	cout << "\n__   __________________________________________________   __";
	cout << "\n  | |                                                  | |  ";
}
//shows the death screen

void showCommands()
{
	cout << "\nnext --> go to the next room";
	cout << "\nright--> go right";
	cout << "\nleft-- > go left";
	cout << "\ninventory-- > shows your inventory";
	cout << "\nHP --> checks your HP";
	cout << "\npotion --> uses a potion to restore your HP";
	cout << "\ncommands --> shows the commands";
	cout << "\nexit --> end the game";
}
//shows all the posible commands

void invalidCommand()
{
	cout << "Invalid command, please enter commands to show the commands";
}
//shows an error message

void randomRooms(int a[], bool& b, bool c[])
{
	a[1] = 1;
	a[2] = rand() % 3 + 2;
	while (true)
	{
		a[3] = rand() % 4 + 2;
		if (a[2] != a[3])
			break;
	}
	while (true)
	{
		a[4] = rand() % 4 + 2;
		if (a[2] != a[4] and a[3] != a[4])
			break;
	}
	a[5] = 0;

	if (rand() % 2 == 0)
		b = true;
	else
		b = false;

	for (int i = 0; i < 6; i++)
		c[i] = true;
}
//randomizes the types of rooms (a), where the boss is (b) and marks that you havent cleared this rooms yet (c)

class enemy
{
public:
	string race;
	string weapon;

	int HP = 4;
	int spd = 2;
	int dmg = 2;
};

int basics[3][3] = { {4, 1, 1}, {2, 2, 2}, {1, 1, 3} };
void randomEnemies(int a, enemy e[], int basics[3][3])
{
	srand(time(0));
	for (int i = 0; i < a; i++)
	{
		int x = rand() % 3;
		if (x == 0)
		{
			e[i].race = "Goblin";
			e[i].spd = basics[0][0];
			e[i].dmg = basics[0][1];
			e[i].HP = basics[0][2];

			if (rand() % 2 == 0)
				e[i].weapon = "Spear";
			else
			{
				e[i].weapon = "Bow";
				e[i].spd = e[i].spd * 2;
			}

		}
		else if (x == 1)
		{
			e[i].race = "Black ork";
			e[i].spd = basics[1][0];
			e[i].dmg = basics[1][1];
			e[i].HP = basics[1][2];

			if (rand() % 2 == 0)
			{
				e[i].weapon = "Sword";
				e[i].spd = e[i].spd / 2;
				e[i].dmg = e[i].dmg * 2;
			}
			else
			{
				e[i].weapon = "Bow";
				e[i].spd = e[i].spd * 2;
				e[i].dmg = e[i].dmg / 2;
			}
		}
		else
		{
			e[i].race = "Troll";
			e[i].spd = basics[2][0];
			e[i].dmg = basics[2][1];
			e[i].HP = basics[2][2];

			if (rand() % 2 == 0)
				e[i].weapon = "Spear";
			else
			{
				e[i].weapon = "Sword";
				e[i].dmg = e[i].dmg * 2;
			}
		}

	}
}
//randomizes 'a' enemies

void bossFight(enemy boss, int& HP, int maxHP, int inventory[], string items[])
{
	int turn = 2;
	if (boss.spd > 3)
		turn = 2;
	while (true)
	{
		if (HP <= 0 or boss.HP <= 0)
			break;

		turn += 1;
		if (turn % 2 == 0)
		{
			int attackCoice;
			cout << "\n\nYou attack!";

			cout << "\n\n1: Bow (dmg = " << inventory[0] << ")\t\t2: Sword (dmg = " << inventory[1] << ")";
			cout << "\n3: Spear (dmg = " << inventory[2] << ")\t\t4: Potion (potions left: " << inventory[3] << ")";
			cout << "\nEnter your action number: ";
			while (true)
			{
				cin >> attackCoice;
				if (cin.fail())
				{
					cin.clear();
					cin.ignore(256, '\n');
					attackCoice = 87;
					cout << "\nPlease select a weapon with it's number";
				}
				else if (attackCoice < 1 or attackCoice > 4)
					cout << "\nPlease input a number between 1 and 4";
				else if (attackCoice == 4)
				{
					if (inventory[3] > 0)
					{
						HP = maxHP;
						inventory[3] -= 1;
						cout << "\nYou have used a potion and restored your HP!\nPotions left: " << inventory[3] << '\n';
						system("pause");
						break;
					}
					else
						cout << "\nYou don't have any potions!\nPlease enter annother action";
				}
				else
				{
					cout << "\nYou decide to attack the " << boss.race << " with a " << items[attackCoice - 1];
					if (attackCoice - 1 == 0)
					{
						if (boss.weapon == "Bow")
						{
							boss.HP -= inventory[attackCoice - 1];
						}
						else if (boss.weapon == "Sword")
						{
							if (inventory[attackCoice - 1] % 2 == 0)
								boss.HP -= (inventory[attackCoice - 1] / 2);
							else
								boss.HP -= ((inventory[attackCoice - 1] + 1) / 2);
							cout << "\nIt's not very effective...";
						}
						else
						{
							boss.HP -= (inventory[attackCoice - 1] * 2);
							cout << "\nIt's very effective!";
						}

					}
					else if (attackCoice - 1 == 1)
					{
						if (boss.weapon == "Bow")
						{
							boss.HP -= (inventory[attackCoice - 1] * 2);
							cout << "\nIt's very effective!";
						}
						else if (boss.weapon == "Sword")
						{
							boss.HP -= inventory[attackCoice - 1];
						}
						else
						{
							if (inventory[attackCoice - 1] % 2 == 0)
								boss.HP -= (inventory[attackCoice - 1] / 2);
							else
								boss.HP -= ((inventory[attackCoice - 1] + 1) / 2);
							cout << "\nIt's not very effective...";
						}
					}
					else
					{
						if (boss.weapon == "Bow")
						{
							if (inventory[attackCoice - 1] % 2 == 0)
								boss.HP -= (inventory[attackCoice - 1] / 2);
							else
								boss.HP -= ((inventory[attackCoice - 1] + 1) / 2);
							cout << "\nIt's not very effective...";
						}
						else if (boss.weapon == "Sword")
						{
							boss.HP -= (inventory[attackCoice - 1] * 2);
							cout << "\nIt's very effective!";
						}
						else
						{
							boss.HP -= inventory[attackCoice - 1];
						}
					}

					if (boss.HP <= 0)
					{
						cout << "\n\nThe " << boss.race << " is dead!!!!";
						break;
					}
					else
					{
						cout << "\n\n" << boss.race << "'s HP: " << boss.HP << "\n\n";
						system("pause");
						break;
					}
				}

			}
		}
		else
		{
			cout << "\n\nThe " << boss.race << " is attacking!!!\n\n";
			system("pause");

			HP -= boss.dmg;

			if (HP <= 0)
				cout << "\n\nThe " << boss.race << " has killed you...";
			else
				cout << "\n\nThe " << boss.race << " caused you " << boss.dmg << " damage, you are now on " << HP << " HP";

		}
	}
}

int main()
{
	srand(time(0));
	titleScreen();

	string command;
	//input by user
	int inventory[4] = { 1, 1, 1, 0 };
	//bow power, sword power, spear power, number of potions
	string items[4] = { "bow", "sword","spear", "potion" };
	//name of the items
	int room[6]{};
	//indicates the type of room each room is
	bool newRoom[6]{ true, true, true, true, true, true };
	//indicates if the player has already cleared the rooms
	int currentRoom = 1;
	//indicates the room the player is currently in
	bool bossAt5 = true;
	//decides where the boss room is (room 5 or room 6)
	randomRooms(room, bossAt5, newRoom);

	int maxHP = 20;
	int HP = maxHP;
	int speed = 3;

	enemy enm[3]{};

	int bossCount = 0;


	cout << "\nYou are at the entrance of the dungeon, please enter next to go in";


	while (true)
	{
		if (HP <= 0)
			break;
		srand(time(0));
		cout << "\n\n\n\nEnter a command \n>";
		cin >> command;
		cout << "\n______________________________________________________________________________\n\n";

		if (command == "exit")
			break;
		else if (command == "next")
		{
			if (currentRoom >= 2 and currentRoom <= 4)
				invalidCommand();
			else if (currentRoom == 1)
				currentRoom += 1;
			else
			{
				randomRooms(room, bossAt5, newRoom);
				currentRoom = 1;
				for (int i = 0; i < 3; i++) //This makes the enemys harder for the next round
					basics[i][rand() % 3] += 1;
			}
		}
		else if (command == "left")
		{
			if (currentRoom < 2 or currentRoom > 4)
				invalidCommand();
			else if (currentRoom == 2)
			{
				currentRoom = 3;
				if (newRoom[currentRoom] == false)
					cout << "\nYou enter an empty room, there is a door at the right and another on the left.";
			}
			else if (currentRoom == 3)
			{
				if (bossAt5 == true)
					currentRoom = 5;
				else
					cout << "The door is closed, maybe you can try to go to the other side...";
			}
			else
			{
				currentRoom = 2;
				if (newRoom[currentRoom] == false)
					cout << "\nYou enter an empty room, there is a door at the right and another on the left.";
			}

		}
		else if (command == "right")
		{
			if (currentRoom < 2 or currentRoom > 4)
				invalidCommand();
			else if (currentRoom == 2)
			{
				currentRoom = 4;
				if (newRoom[currentRoom] == false)
					cout << "\nYou enter an empty room, there is a door at the right and another on the left.";
			}
			else if (currentRoom == 3)
			{
				currentRoom = 2;
				if (newRoom[currentRoom] == false)
					cout << "\nYou enter an empty room, there is a door at the right and another on the left.";
			}
			else
			{
				if (bossAt5 == false)
					currentRoom = 5;
				else
					cout << "The door is closed, maybe you can try to go to the other side...";
			}
		}
		else if (command == "inventory")
		{
			cout << "\nYour bow has power " << inventory[0] << ", your sword has power " << inventory[1] << ", your spear has power " << inventory[2] << " and you have " << inventory[3] << " healing potions.";
		}
		else if (command == "potion")
		{
			if (inventory[3] > 0)
			{
				HP = maxHP;
				inventory[3] -= 1;
				cout << "\nYou have used a potion and restored your HP!\nPotions left: " << inventory[3] << '\n';
				system("pause");
			}
			else
				cout << "\nYou don't have any potions!";
		}
		else if (command == "commands")
			showCommands();
		else if (command == "HP")
			cout << "\nYou have " << HP << " HP points left";
		else
			invalidCommand();

		if (newRoom[currentRoom] == true)
		{

			if (room[currentRoom] == 1) //this is a safe room
			{
				cout << "\nYou have descended into the next dungeon level, your HP has been restored";
				HP = maxHP;
			}
			else if (room[currentRoom] == 5) //this is a chest room
			{
				cout << "\nYou have entered a chest room";
				int r = rand() % 4;
				if (r == 3)
				{
					inventory[r] += 1;
					cout << "\nYou have found a potion, you have now " << inventory[r] << " potions";
				}
				else
				{
					inventory[r] += rand() % 2 + 1;
					cout << "\nYou found a " << items[r] << " with a power of " << inventory[r];
				}

			}
			else if (room[currentRoom] == 0) //this is a boss room
			{
				int rr = rand() % 3;
				bossCount += 1;

				if (bossCount == 1)
					rr = 1;
				else if (bossCount == 2)
					rr = 2;
				else if (bossCount == 3)
					rr = 0;

				if (rr == 0)
				{
					cout << "\n\n\nYou entered a room with a... DRAGON!!!";

					cout << "\n                \\||/";
					cout << "\n                |  @___oo";
					cout << "\n      /\\  /\\   / (__,,,,|";
					cout << "\n     ) /^\\) ^\\/ _)";
					cout << "\n     )   /^\\/   _)";
					cout << "\n     )   _ /  / _)";
					cout << "\n /\\  )/\\/ ||  | )_)";
					cout << "\n<  >      |(,,) )__)";
					cout << "\n ||      /    \\)___)\\";
					cout << "\n | \\____(      )___) )___";
					cout << "\n  \\______(_______;;; __;;;\n\n";

					system("pause");

					enemy dragon;
					dragon.HP = 10;
					dragon.spd = 1;
					dragon.dmg = 5;
					dragon.race = "dragon";
					dragon.weapon = "Bow";


					cout << "\n\nThe " << dragon.race << " wants to fight!!!";

					bossFight(dragon, HP, maxHP, inventory, items);

				}
				else if (rr == 1)
				{
					cout << "\n\n\nYou enter a room with a... unicorn?";

					cout << "\n         . ";
					cout << "\n        /'";
					cout << "\n       //";
					cout << "\n   .  // ";
					cout << "\n   |\\//7";
					cout << "\n  /' \" \\";
					cout << "\n .   . .";
					cout << "\n | (    \\     '._";
					cout << "\n |  '._  '    '. '";
					cout << "\n /    \\'-'_---. ) )";
					cout << "\n.              :.'";
					cout << "\n|               \\";
					cout << "\n| .    .   .     .";
					cout << "\n' .    |  |      |";
					cout << "\n \\^   /_-':     /";
					cout << "\n / | |    '\\  .'";
					cout << "\n/ /| |     \\\\  |";
					cout << "\n\\ \\( )     // /";
					cout << "\n \\ | |    // /";
					cout << "\n  L! !   // /";
					cout << "\n   [_]  L[_| \n\n";

					system("pause");

					enemy unicorn;
					unicorn.HP = 5;
					unicorn.spd = 8;
					unicorn.dmg = 3;
					unicorn.race = "unicorn";
					unicorn.weapon = "Spear";


					cout << "\n\nThe " << unicorn.race << " wants to fight!!!";

					bossFight(unicorn, HP, maxHP, inventory, items);
				}
				else if (rr == 2)
				{
					cout << "\nYou enter a room with a bear!";

					cout << "\n     (()__(()";
					cout << "\n     /       \\";
					cout << "\n    ( /    \\  \\";
					cout << "\n     \\ o o    /";
					cout << "\n     (_()_)__/ \\";
					cout << "\n    / _,==.____ \\";
					cout << "\n   (   |--|      )";
					cout << "\n   /\\_.|__|'-.__/\\_";
					cout << "\n  / (        /     \\";
					cout << "\n  \\  \\      (      /";
					cout << "\n   )  '._____)    / ";
					cout << "\n(((____.--(((____/\n\n";

					system("pause");

					enemy bear;
					bear.HP = 8;
					bear.spd = 2;
					bear.dmg = 4;
					bear.race = "bear";
					bear.weapon = "Sword";


					cout << "\n\nThe " << bear.race << " wants to fight!!!";

					bossFight(bear, HP, maxHP, inventory, items);
				}

				cout << "\n\n";
				system("pause");

				if (HP > 0)
				{
					int r = rand() % 4;
					if (r == 3)
					{
						inventory[r] += 1;
						cout << "\nYou have found a potion, you have now " << inventory[r] << " potions";
					}
					else
					{
						inventory[r] += rand() % 2 + 1;
						cout << "\nYou found a " << items[r] << " with a power of " << inventory[r];
					}
				}
				else
					bossAt5 -= 1;
			}
			else //this room has enemies
			{
				randomEnemies(room[currentRoom] - 1, enm, basics);
				cout << "\nYou have entered a room with enemies";
				for (int i = 1; i < room[currentRoom]; i++)
					cout << "\nThere is a " << enm[i - 1].race << " with a " << enm[i - 1].weapon;

				cout << "\n\n";
				system("pause");

				int attackOrder[4] = { -1, -1, -1, -1 };
				//marks the order in wich the player and the enemies will atack
				bool isOrdered[4] = { false, false, false, false };
				//helps us see who we have ordered already (0, 1 and 2 are enemies, and 3 is the player)

				for (int j = 0; j < room[currentRoom]; j++) //Decide the order of attacks
				{
					int fastestSpeedHolder = 0;
					int fastestSpeed = 0;
					for (int i = -1; i < room[currentRoom] - 1; i++)
					{
						if (i == -1)
						{
							if (isOrdered[3] == false)
							{
								fastestSpeed = speed;
								fastestSpeedHolder = 3;
							}
							else if (isOrdered[0] == false)
							{
								fastestSpeed = enm[0].spd;
								fastestSpeedHolder = 0;
							}
							else if (isOrdered[1] == false)
							{
								fastestSpeed = enm[1].spd;
								fastestSpeedHolder = 1;
							}
							else
							{
								fastestSpeed = enm[2].spd;
								fastestSpeedHolder = 2;
							}
						}
						else
						{
							if (isOrdered[i] == false)
							{
								if (fastestSpeed < enm[i].spd)
								{
									fastestSpeed = enm[i].spd;
									fastestSpeedHolder = i;
								}
							}
						}
					}

					attackOrder[j] = fastestSpeedHolder;
					isOrdered[fastestSpeedHolder] = true;
				}


				int aliveEnemies = room[currentRoom] - 1;
				bool playerIsAlive = true;
				while (true) //Combat
				{
					if (aliveEnemies == 0 or playerIsAlive == false)
						break;

					for (int i = 0; i < room[currentRoom]; i++)
					{
						if (attackOrder[i] == 3) //Player attack
						{
							int attackCoice;
							cout << "\n\nYou attack!";
							while (true)
							{
								cout << "\n\n1: Bow (dmg = " << inventory[0] << ")\t\t2: Sword (dmg = " << inventory[1] << ")";
								cout << "\n3: Spear (dmg = " << inventory[2] << ")\t\t4: Potion (potions left: " << inventory[3] << ")";
								cout << "\nEnter your action number: ";
								cin >> attackCoice;
								if (cin.fail())
								{
									cin.clear();
									cin.ignore(256, '\n');
									attackCoice = 87;
								}

								if (attackCoice >= 1 and attackCoice <= 3)
								{
									int target = 87;
									cout << "\n\nYou decide to use the " << items[attackCoice - 1] << "\n";
									for (int i = 0; i < room[currentRoom] - 1; i++)
									{
										if (enm[i].HP > 0)
										{
											cout << "\n" << i + 1 << ": " << enm[i].race << " with a " << enm[i].weapon;
											cout << "\n\tHP: " << enm[i].HP << "\n";
										}
										else
											cout << "\n" << i + 1 << ": already dead!\n";
									}

									while (true)
									{
										cout << "\n\nSelect your target: ";
										cin >> target;
										if (cin.fail())
										{
											cin.clear();
											cin.ignore(256, '\n');
											target = 87;
										}
										else if (target < 1 or target >= room[currentRoom])
											cout << "\nPlease input a number from 1 to " << room[currentRoom] - 1;
										else if (enm[target - 1].HP <= 0)
											cout << "\nPlease select an enemy who isn't dead";
										else
											break;
									}

									cout << "\n\n\nYou attacked the " << enm[target - 1].race << " with a " << enm[target - 1].weapon << " with a " << items[attackCoice - 1];

									//this transforms the damage depending on how effective it is (ex. bow on sword = *2 dmg)
									if (attackCoice - 1 == 0)
									{
										if (enm[target - 1].weapon == "Bow")
										{
											enm[target - 1].HP -= inventory[attackCoice - 1];
										}
										else if (enm[target - 1].weapon == "Sword")
										{
											if (inventory[attackCoice - 1] % 2 == 0)
												enm[target - 1].HP -= (inventory[attackCoice - 1] / 2);
											else
												enm[target - 1].HP -= ((inventory[attackCoice - 1] + 1) / 2);
											cout << "\nIt's not very effective...";
										}
										else
										{
											enm[target - 1].HP -= (inventory[attackCoice - 1] * 2);
											cout << "\nIt's very effective!";
										}

									}
									else if (attackCoice - 1 == 1)
									{
										if (enm[target - 1].weapon == "Bow")
										{
											enm[target - 1].HP -= (inventory[attackCoice - 1] * 2);
											cout << "\nIt's very effective!";
										}
										else if (enm[target - 1].weapon == "Sword")
										{
											enm[target - 1].HP -= inventory[attackCoice - 1];
										}
										else
										{
											if (inventory[attackCoice - 1] % 2 == 0)
												enm[target - 1].HP -= (inventory[attackCoice - 1] / 2);
											else
												enm[target - 1].HP -= ((inventory[attackCoice - 1] + 1) / 2);
											cout << "\nIt's not very effective...";
										}
									}
									else
									{
										if (enm[target - 1].weapon == "Bow")
										{
											if (inventory[attackCoice - 1] % 2 == 0)
												enm[target - 1].HP -= (inventory[attackCoice - 1] / 2);
											else
												enm[target - 1].HP -= ((inventory[attackCoice - 1] + 1) / 2);
											cout << "\nIt's not very effective...";
										}
										else if (enm[target - 1].weapon == "Sword")
										{
											enm[target - 1].HP -= (inventory[attackCoice - 1] * 2);
											cout << "\nIt's very effective!";
										}
										else
										{
											enm[target - 1].HP -= inventory[attackCoice - 1];
										}
									}


									if (enm[target - 1].HP <= 0)
									{
										cout << "\n\tYou killed him!!!";
										aliveEnemies -= 1;
									}
									else
										cout << "\n\tHis HP: " << enm[target - 1].HP;

									cout << '\n';
									system("pause");
									break;
								}
								else if (attackCoice == 4)
								{
									if (inventory[3] > 0)
									{
										HP = maxHP;
										inventory[3] -= 1;
										cout << "\nYou have used a potion and restored your HP!\nPotions left: " << inventory[3] << '\n';
										system("pause");
										break;
									}
									else
										cout << "\nYou don't have any potions!\nPlease enter annother action";
								}
								else
									cout << "\nPlease input a number from 1 to 4";
							}
						}
						else //Enemy attack
						{
							if (enm[attackOrder[i]].HP > 0)
							{
								cout << "\n\n> " << enm[attackOrder[i]].race << " with a " << enm[attackOrder[i]].weapon << " attacks";
								HP -= enm[attackOrder[i]].dmg;

								if (HP <= 0)
								{
									cout << "\n\nYOU DIED!!!";
									playerIsAlive = false;
									break;
								}
								else
									cout << "\n\nHe caused you " << enm[attackOrder[i]].dmg << " HP of damage\nYou have: " << HP << " HP\n";
								system("pause");
							}
						}
					}
				}
				if (playerIsAlive == false)
					break;
			}

			newRoom[currentRoom] = false;
		}


	}

	deathScreen();
	cout << "\n\n\n";
	system("pause");
	cout << "\nThank you for playing!\n\nBosses beaten: " << bossCount << "\n\n";
	titleScreen();
}